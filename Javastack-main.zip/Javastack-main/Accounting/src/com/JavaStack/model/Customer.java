package com.JavaStack.model;

public class Customer {

}
