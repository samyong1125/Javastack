/**
 * 
 */
/**
 * 
 */
module JavaStack {
	requires java.sql;
}